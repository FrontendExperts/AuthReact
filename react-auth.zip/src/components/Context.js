import { createContext } from "react";

export const CountContext = createContext();

