import React from "react";
import { useState } from "react";

export const Hook = () => {
  const [count, setCount] = useState(0);

  return (
    <>
      <section className="text-center">
        <div className="container">
          <h2>Counter by the Hook </h2>

          <div className="box">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => (count === 0 ? setCount(0) : setCount(count - 1))}
            >
              -
            </button>

            <h2> {count} </h2>

            <button
              type="button"
              className="btn btn-primary"
              onClick={() => setCount(count + 1)}
            >
              +
            </button>
          </div>
        </div>
      </section>
    </>
  );
};
