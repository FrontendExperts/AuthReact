import { React, useState, useEffect } from "react";
import { NavLink,useLocation } from "react-router-dom";
import { useAuth0 } from "@auth0/auth0-react";
import {MetaTitle, MetaDescription} from "../Meta"
// import { CountContext } from "../Context";

const Header = () => {
  const [openMenu, setOpenMenu] = useState(false);
  const {pathname} = useLocation();
  const { isAuthenticated, loginWithRedirect, logout, user } = useAuth0();
  // const [count2, setCount2] = useState(0);
  // const {count1, setCount1} = useContext(CountContext);

  //  useEffect(() => {
  //      console.log(isAuthenticated)
  //  }, [isAuthenticated]);

  //  useEffect(() => {
  //   console.log(count1,count2)
  // }, [])

  // const { isAuthenticated, user, loginWithRedirect, logout } = useAuth0<{
  //     name: string;
  //   }>();
  //   const { pathname } = useLocation();



  useEffect(()=>{
    window.scrollTo(0,0);
    //console.log(pathname)

    MetaTitle( 
      pathname === '/' ? 'Home Page Title' : 
     pathname === '/about' ? 'About New Page Title' :
     pathname === '/contact' ? 'Contact us New Page Title' :
     pathname === '/hook' ? 'Hook Page Title' : 
     'Unknown Title' );
    MetaDescription(
     pathname === '/' ? 'Home Page Description' : 
    pathname === '/about' ? 'About New Page Description' : 
    pathname === '/hook' ? 'Hook Page Description' : 
    pathname === '/contact' ? 'Contactus New Page Description' :  
    'Unknown Description');

  }, [pathname])


  return (
    <>
      <nav class="navbar navbar-expand-lg bg-dark">
        <div class="container-fluid">
          <NavLink className="navbar-brand" to="/">
            Logo
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse justify-content-end"
            id="navbarSupportedContent"
          >
            <ul className="navbar-nav text-white">
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  aria-current="page"
                  to="/"
                >
                  Home
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/about"
                >
                  About us
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/fatchapi"
                >
                  Get Fatch API
                </NavLink>
              </li>

             

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/hook"
                >
                  Hook in React
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/contact"
                >
                  Contact
                </NavLink>
              </li>

              {/* {isAuthenticated && (
                <li>
                  <p> {user.name} </p>
                </li>
              )} */}

              {isAuthenticated ? (
                <>
                
                  <li className="nav-item">
                    <NavLink
                      className="nav-link"
                      activeClassName="active"
                      to="/profile"
                    >
                      Profile
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <button className="btn btn-primary"
                      onClick={() =>
                        logout({ returnTo: window.location.origin })
                      }
                    >
                      Logout
                    </button>
                  </li>
                </>
              ) : (
                <li className="nav-item">
                  <button className="btn btn-primary" onClick={() => loginWithRedirect()}>Login</button>
                </li>
              )}
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Header;
