import React from "react";
import { useAuth0 } from "@auth0/auth0-react";

const Profile = () => {
  const { user, isAuthenticated, isLoading } = useAuth0();

  if (isLoading) {
    return <div>Loading ...</div>;
  }

  return (
    isAuthenticated && (
      <>
        <section className="text-center">
          <div className="container">
            <img src={user.picture} alt={user.name} />
            <h2>User Information: {user.name}</h2>
            <p>User Email: {user.email}</p>
          </div>
        </section>
      </>
    )
  );
};

export default Profile;
