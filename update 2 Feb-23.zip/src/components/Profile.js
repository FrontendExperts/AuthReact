import React from "react";
import { useEffect, useState,useContext } from 'react';
import {BrowserRouter as Router, Routes,Route,Link,useNavigate } from 'react-router-dom';
import { userContext } from './contexts/';

const Profile = () => {

  const [auth,setAuth]=useState('');
  let navigate = useNavigate(); // Use for Navigate on Previous



  const {user, setUser} = useContext(userContext);
  
  
  useEffect(()=>{
      var auth = localStorage.getItem('email'); 
      setAuth(auth);
    },
    [])
  if(auth===null){
      navigate(`/signin`);
  }


  // if (isLoading) {
  //   return <div>Loading ...</div>;
  // }

  return (

      <>
        <section className="text-center">
          <div className="container">
            <img src={user} alt={user} />
            <h2>User Information: {user}</h2>
            <p>User Email: {auth}</p>
          </div>
        </section>
      </>

  );
};

export default Profile;






