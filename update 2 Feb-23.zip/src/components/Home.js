import React from 'react'

const Home = () => {
  return (

    <section className="text-center">
        <div className="container">
            <h2>Welcome to Homepage</h2>
        </div>
      </section>
  )
}

export default Home
