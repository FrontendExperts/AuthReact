import { React, useState } from "react";

const Contact = () => {
  const [popupStyle, showPopup] = useState("hide");

  const showPopupMsg = () => {
    showPopup("login-popup");
    setTimeout(() => showPopup("hide"), 3000);
  };

  return (
    <>
      <section className="text-center">
        <div className="container">
        <h2>This is Contact Page</h2>
        <button className="btn btn-primary" onClick={showPopupMsg}>
        Popup
      </button>

      <div className={popupStyle}>
        <div className="modal-content">
          <h4>Popup title</h4>
          <p>this is a popup message</p>
        </div>
      </div>
        </div>
      </section>

     

      
    </>
  );
};

export default Contact;
