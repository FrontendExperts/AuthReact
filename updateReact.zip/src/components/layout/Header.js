import { React, useState, useEffect, useContext } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { userContext } from "../Context";
// import { useAuth0 } from "@auth0/auth0-react";
import { MetaTitle, MetaDescription } from "../Meta";
// import Profile from "../Profile";

// import { CountContext } from "../Context";

const Header = () => {
  const [openMenu, setOpenMenu] = useState(false);
  const { pathname } = useLocation();
  const isLoggedIn = window.localStorage.getItem("loggedIn");
  const {user, setUser} = useContext(userContext);

  // const [count2, setCount2] = useState(0);
  // const {count1, setCount1} = useContext(CountContext);

  // const [auth,setAuth]=useState('');
  // const { auth,  LogOut } = useState();
  // const [user, setUser] = useState(localStorage.getItem("userName")||"");
  let navigate = useNavigate();

  // useEffect(() => {
  //   // console.log(auth)
  //   // var auth = localStorage.getItem('email');
  //   var userName = localStorage.getItem("userName");

  //   // if(auth === null){
  //   //   navigate(`/signin`);
  //   // }

  //   // setAuth(auth);
  //   setUser(userName);
  // }, []);

  // useEffect(() => {

  //   localStorage.setItem("userName", user);


  // }, [user]);


  const LogOut = () => {
    localStorage.removeItem("email");
    localStorage.clear();
    navigate(`/signin`);
    setUser("")
  };

  //  useEffect(() => {
  //      console.log(isAuthenticated)
  //  }, [isAuthenticated]);

  //  useEffect(() => {
  //   console.log(count1,count2)
  // }, [])

  // const { isAuthenticated, user, loginWithRedirect, logout } = useAuth0<{
  //     name: string;
  //   }>();
  //   const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
    //console.log(pathname)

    MetaTitle(
      pathname === "/"
        ? "Home Page Title"
        : pathname === "/about"
        ? "About New Page Title"
        : pathname === "/contact"
        ? "Contact us New Page Title"
        : pathname === "/hook"
        ? "Hook Page Title"
        : pathname === "/signin"
        ? "Login Page"
        : pathname === "/register"
        ? "Register Page"
        : pathname === "/profile"
        ? "Welcome To My Website {user}"
        : "Unknown Title"
    );
    MetaDescription(
      pathname === "/"
        ? "Home Page Description"
        : pathname === "/about"
        ? "About New Page Description"
        : pathname === "/hook"
        ? "Hook Page Description"
        : pathname === "/contact"
        ? "Contactus New Page Description"
        : pathname === "/signin"
        ? "This is Login Page"
        : pathname === "/register"
        ? "Register Page"
        : pathname === "/profile"
        ? "Welcome To My Website"
        : "Unknown Description"
    );
  }, [pathname]);

  return (
    <>
      <nav class="navbar navbar-expand-lg bg-dark sticky-top">
        <div class="container-fluid">
          <NavLink className="navbar-brand" to="/">
            Logo
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse justify-content-end"
            id="navbarSupportedContent"
          >
            <ul className="navbar-nav text-white">
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  aria-current="page"
                  to="/"
                >
                  Home
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/about"
                >
                  About us
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/fatchapi"
                >
                  Get Fatch API
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/hook"
                >
                  Hook in React
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/contact"
                >
                  Contact
                </NavLink>
              </li>

              {/* <li className="nav-item">
                    <NavLink
                      className="nav-link"
                      activeClassName="active"
                      to="/profile"
                    >
                      Profile
                    </NavLink>
                  </li> */}

              <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/register"
                >
                  Register
                </NavLink>
              </li>

              {user ? (
                <>
                <li className="nav-item me-2">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/profile"
                >
                  Profile
                </NavLink>
                </li>
                
                <li className="nav-item text-white">
                 <span className="me-2">Welcome: {user} </span> 
                  <button className="btn btn-primary logout" to="" onClick={LogOut}> Logout </button>
                </li>
                </>
              ) : (
                <li className="nav-item">
                  <NavLink
                    activeClassName="active"
                    to="/signin">
                    <button className="btn btn-primary">Login </button>
                  </NavLink>
                </li>
              )}
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Header;
