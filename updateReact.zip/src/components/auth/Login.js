import React, {useContext, useState} from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { userContext } from '../Context';

const Signin = () => {

  let navigate = useNavigate();

  const {setUser} = useContext(userContext);

  const [user, updateUser] = useState({
    email:"",
    password:""
})

const handleChange=(e) => {
    updateUser({ ...user, [e.target.name]: e.target.value });

   
}

const submitForm=(e) => {
      e.preventDefault();
      const sendData = {
          email:user.email,
          password:user.password
      }
    //  console.log(sendData)




            axios.post('http://localhost/ReactJS/react-auth0/public/backend/php/login.php', sendData)
            .then((result)=> {
                 if (result.data.Status === '200'){
                     window.localStorage.setItem('email', result.data.email);
                     setUser(result.data.fname );
                    navigate(`/profile`);
                }
                else{
                    
                  alert('Invalid User'); 
                }}
            )   

      }
    
//    useEffect(() => {
//     console.log(user)
//   }, [updateUser])

  return (
    <>
    <section className="text-center">
        <div className="container">
        <h2>Sign in</h2>
        <div className='col-sm-6 m-auto'>
        <form onSubmit={submitForm}>
        <fieldset>

            <div class="mb-3">
            <input type="text" name="email" class="form-control" placeholder="Enter email" onChange={handleChange} value={user.email} required />
            </div>

            <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Create password" onChange={handleChange} value={user.password}  required />
            </div>
           
            <button type="submit" value="login" class="btn btn-primary">Submit</button>
        </fieldset>
        </form>
        </div>

        </div>
    </section>
    
    </>
  )
}

export default Signin