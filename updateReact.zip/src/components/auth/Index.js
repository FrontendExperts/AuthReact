import React from 'react'
// import { Auth0Provider } from '@auth0/auth0-react';
// import { useLocation, Link } from 'react-router-dom';
// import { useAuth0 } from '@auth0/auth0-react';





export const Index = () => {
  return (
    <>
    <Auth0Provider

domain="dev-67jpjy2pbgjsz2fw.us.auth0.com"
clientId="RPAsPO53wSzQ4dGeJ1AxvdamjIIUozrC"
redirectUri={window.location.origin}
> 

    </Auth0Provider> 
    </>
  )
}
