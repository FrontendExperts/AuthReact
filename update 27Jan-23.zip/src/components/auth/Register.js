import axios from 'axios';
import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom';

const Register = () => {

    let history = useNavigate();
        const [data, setData] = useState({
            fname:"",
              email:"",
              phone:"",
              password:""
        })

        const handleChange=(e) => {
              setData({ ...data, [e.target.name]: e.target.value });

             
        }

        const submitForm=(e) => {
            e.preventDefault();
            const sendData = {
                fname:data.fname,
                email:data.email,
                phone:data.phone,
                password:data.password
            }
            
            console.log(sendData)

            axios.post('http://localhost/ReactJS/react-auth0/public/backend/php/insert.php', sendData)
            .then((result)=> {
                if (result.data.status === 'Invalid'){
                    alert('Invalid User')
                    console.log(result.data.status);
                }
                else{
                    history(`/profile`)
                }}
            )   

      }
      


  return (
    <>
    <section className="text-center">
        <div className="container">
        <h2>Register</h2>

        <div className='col-sm-6 m-auto'>
        <form onSubmit={submitForm}>
        <fieldset>
            <legend>Please fill in the form below</legend>
            <div class="mb-3">
            <input type="text" name="fname" class="form-control" placeholder="Enter name" onChange={handleChange} value={data.fname} required/>
            </div>
            <div class="mb-3">
            <input type="text" name="email" class="form-control" placeholder="Enter email" onChange={handleChange} value={data.email} required/>
            </div>
            <div class="mb-3">
            <input type="text" name="phone" class="form-control" placeholder="Enter mobile number" onChange={handleChange} value={data.phone} required/>
            </div>
            <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Create password" onChange={handleChange} value={data.password} required/>
            </div>
            {/* <div class="mb-3">
            <select id="disabledSelect" class="form-select">
                <option>Disabled select</option>
                
            </select>
            </div> */}
            {/* <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="disabledFieldsetCheck" disabled />
                <label class="form-check-label" for="disabledFieldsetCheck">
                Can't check this
                </label>
            </div>
            </div> */}
            <button type="submit" value="register" class="btn btn-primary">Register</button>
        </fieldset>
        </form>
        </div>
        


        </div>
    </section>
    
    </>
  )
}

export default Register