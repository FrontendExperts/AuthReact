import React, { useContext } from "react";
import { CountContext } from "./contexts/Index";

export const Hook = () => {
  // const [count, setCount] = useState(0);
  const { count, increaseCount, decreaseCount } = useContext(CountContext);

  return (
    <>
      <section className="text-center">
        <div className="container">
          <h2>Counter by the Hook </h2>

          <div className="box11">
            <p>Count is: {count} </p>
            <button className="btn btn-danger" onClick={decreaseCount}>
              - Decreass
            </button>
            <button className="btn btn-primary" onClick={increaseCount}>
              + Increase
            </button>
          </div>
        </div>
      </section>
    </>
  );
};
