import React from "react";
import { useEffect, useState } from 'react';
import {BrowserRouter as Router, Routes,Route,Link,useNavigate } from 'react-router-dom';

const Profile = () => {

  const [auth,setAuth]=useState('');
  let navigate = useNavigate(); // Use for Navigate on Previous
  useEffect(()=>{
      var auth = localStorage.getItem('email'); 
      setAuth(auth);
    },
    [])
  if(auth===null){
      navigate(`/signin`);
  }


  // if (isLoading) {
  //   return <div>Loading ...</div>;
  // }

  return (

      <>
        <section className="text-center">
          <div className="container">
            {/* <img src={user.picture} alt={user.fname} /> */}
            <h2>User Information: </h2>
            <p>User Email:</p>
          </div>
        </section>
      </>

  );
};

export default Profile;






