import React from 'react'

export const Footer = () => {
  return (
    <>  
    <footer className='footer'>
        <div className='copyright'>Copyright © 2023 ReactJs</div>
    </footer>
    </>
    
  )
}
