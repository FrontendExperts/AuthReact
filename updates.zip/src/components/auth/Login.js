import React, {useState} from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Signin = () => {

  let navigate = useNavigate();

  const [user, setUser] = useState({
    email:"",
    password:""
})

const handleChange=(e) => {
    setUser({ ...user, [e.target.name]: e.target.value });

   
}

const submitForm=(e) => {
      e.preventDefault();
      const sendData = {
          email:user.email,
          password:user.password
      }
     // console.log(sendData)




            axios.post('http://localhost/ReactJS/react-auth0/public/backend/php/login.php', sendData)
            .then((result)=> {
                 if (result.data.status === '200'){
                    //  window.localStorage.setItem('email', result.data.email);
                    //  window.localStorage.setItem('userName', (result.data.fname+ ' ' +result.data.fname ));  
                     navigate(`/profile`);
                }
                else{
                    alert('Invalid User'); 
                }}
            )   

      }
    
//    useEffect(() => {
//     console.log(user)
//   }, [setUser])

  return (
    <>
    <section className="text-center">
        <div className="container">
        <h2>Sign in</h2>
        <div className='col-sm-6 m-auto'>
        <form onSubmit={submitForm}>
        <fieldset>

            <div class="mb-3">
            <input type="text" name="email" class="form-control" placeholder="Enter email" onChange={handleChange} value={user.email} required />
            </div>

            <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Create password" onChange={handleChange} value={user.password}  required />
            </div>
           
            <button type="submit" value="login" class="btn btn-primary">Submit</button>
        </fieldset>
        </form>
        </div>

        </div>
    </section>
    
    </>
  )
}

export default Signin