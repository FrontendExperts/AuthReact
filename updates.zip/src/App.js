import './App.css';
import Header from './components/layout/Header';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import About from './components/About';
import Contact from './components/Contact';
import Home from './components/Home';
import Profile from './components/Profile';
import { Hook } from './components/Hook';
// import { useState } from 'react';
import Fatchapi from './components/Fatchapi';
import {Footer} from './components/layout/Footer'
import PageNotFound from "./components/Notfound";
import Signin from "./components/auth/Login";
import Register from './components/auth/Register';
// import { CountContext } from './components/Context';




function App() {
  // const [count1, setCount1] = useState(11);

  return (
    <>

   <BrowserRouter>
   {/* <CountContext.Provider value={{count1, setCount1}}> */}
        <Header />
         <main className='my-5'>
          <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/hook" element={<Hook />} />
          <Route path="/fatchapi" element={<Fatchapi />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/register" element={<Register />} />
          <Route path="/signin" element={<Signin />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
        </main>
        <Footer />
        {/* </CountContext.Provider> */}
        </BrowserRouter>
   

    </>
  );
}

export default App;
